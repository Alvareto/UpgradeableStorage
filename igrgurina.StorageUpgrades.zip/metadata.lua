return PlaceObj('ModDef', {
	'title', "Upgradeable Waste Rock Dump Site",
	'tags', "",
	'id', "ranB3gH",
	'author', "Alvareto",
	'version', 33,
	'lua_revision', 228184,
	'code', {
		"Code/PostBuildingUpgradeScript.lua",
		"Code/customWasteRockDumpSmall.lua",
	},
	'saved', 1521876317,
})